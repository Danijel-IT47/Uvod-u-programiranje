﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vezba3Zadatak2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double broj, decimalnaVrednost;
            int ceoBroj;
            string provera;
            bool negativan = false;
            List<int> listaCelogBroja = new List<int>();
            List<int> listaDecimalneVrednosti = new List<int>();
            do
            {
                do
                {
                    Console.Write("Unesite broj: ");
                }
                while (!double.TryParse(Console.ReadLine(), out broj));
                if (broj < 0)
                {
                    broj = -broj;
                    negativan = true;
                }
                ceoBroj = (int)(broj - broj % 1);
                decimalnaVrednost = (broj % 1) * 2;
                while (ceoBroj != 0)
                {
                    listaCelogBroja.Add(ceoBroj % 2);
                    ceoBroj /= 2;
                }
                if (decimalnaVrednost != 0)
                {
                    int n = 0;
                    do
                    {
                        if (n < 19)
                        {
                            decimalnaVrednost = decimalnaVrednost * 2;
                            if (decimalnaVrednost >= 2)
                            {
                                decimalnaVrednost -= 2;
                                listaDecimalneVrednosti.Add(1);
                            }
                            else
                            {
                                listaDecimalneVrednosti.Add(0);
                            }
                        }
                        else break;
                        n++;
                    }
                    while (decimalnaVrednost != 0);
                }
                if (negativan == true)
                {
                    Console.Write("-");
                }
                for (int i = listaCelogBroja.Count - 1; i >= 0; i--)
                {
                    Console.Write(listaCelogBroja[i]);
                }
                if (listaDecimalneVrednosti.Count != 0)
                {
                    Console.Write(".");
                }
                for (int i = 0; i < listaDecimalneVrednosti.Count; i++)
                {
                    Console.Write(listaDecimalneVrednosti[i]);
                }
                Console.Write("\n");
                provera = Console.ReadLine();
            }
            while (provera != "kraj");
            Console.ReadKey();
        }
    }
}
