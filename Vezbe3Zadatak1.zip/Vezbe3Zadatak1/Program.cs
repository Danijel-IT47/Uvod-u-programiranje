﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vezbe3Zadatak1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int prviBroj, drugiBroj;
            bool indikator;
            do
            {
                Console.Write("Unesite prvi broj: ");
            }
            while(!int.TryParse(Console.ReadLine(), out prviBroj) );
            do
            {
                Console.Write("Unesite drugi broj: ");
            }
            while (!int.TryParse(Console.ReadLine(), out drugiBroj));
            //_ = prviBroj % 2 == 0 & drugiBroj % 2 == 0 ? indikator = true : indikator = false;
            if(prviBroj % 2 == 0 & drugiBroj % 2 == 0)
            {
                indikator = true;
            }
            else
            {
                indikator = false;
            }
            Console.WriteLine(indikator);
            Console.ReadKey();
        }
    }
}
