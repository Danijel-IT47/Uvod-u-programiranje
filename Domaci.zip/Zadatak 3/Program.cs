﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double celsius;
            bool inputControl;
            do
            {
                Console.Write("Unesite temperaturu u celsiusu: ");
                inputControl = double.TryParse(Console.ReadLine(), out celsius);
            }
            while(!inputControl);
            Console.WriteLine("Temperatura u kelvinu je {0}\nTemperatura u ferenhajtu je {1}", CelsiusToKelvin(celsius), CelsiusToFahrenheit(celsius));
        }

        static double CelsiusToKelvin(double celsius)
        {
            return celsius + 273;
        }

        static double CelsiusToFahrenheit(double celsius)
        {
            return celsius * 18 / 10 + 32;
        }
    }
}
