﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a, b, c;
            bool proveraA, proveraB;
            do
            {
                Console.Write("Unesi duzinu stranice a: ");
                proveraA = double.TryParse(Console.ReadLine(), out a);
            }
            while(!proveraA);
            do
            {
                Console.Write("Unesi duzinu stranice b: ");
                proveraB = double.TryParse(Console.ReadLine(), out b);
            }
            while(!proveraB);
            c = Hipotenuza(a, b);
            Console.WriteLine("c = {0}", c);
        }

        static double Hipotenuza(double a, double b)
        {
            return Math.Sqrt(a * a + b * b);
        }
    }
}
