﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int prviBroj, drugiBroj;
            bool proveraPrvogBroja, proveraDrugogBroja;
            do
            {
                Console.Write("Unesite prvi broj: ");
                proveraPrvogBroja = int.TryParse(Console.ReadLine(), out prviBroj);
            }
            while (!proveraPrvogBroja);
            do
            {
                Console.Write("Unesite drugi broj: ");
                proveraDrugogBroja = int.TryParse(Console.ReadLine(), out  drugiBroj);
            }
            while (!proveraDrugogBroja);
            Console.WriteLine("{0} + {1} = {2}", prviBroj, drugiBroj, Sabiranje(prviBroj, drugiBroj));
            Console.WriteLine("{0} - {1} = {2}", prviBroj, drugiBroj, Oduzimanje(prviBroj, drugiBroj));
            Console.WriteLine("{0} * {1} = {2}", prviBroj, drugiBroj, Mnozenje(prviBroj, drugiBroj));
            Console.WriteLine("{0} + {1} = {2}(deljenje bez ostatka)", prviBroj, drugiBroj, DeljenjeBezOstatka(prviBroj, drugiBroj));
            Console.WriteLine("{0} + {1} = {2}", prviBroj, drugiBroj, Deljenje(prviBroj, drugiBroj));
            Console.WriteLine("{0} + {1} = {2}", prviBroj, drugiBroj, OstatakPriDeljenju(prviBroj, drugiBroj));
        }

        static int Sabiranje(int a, int b)
        {
            return a + b;
        }

        static int Oduzimanje(int a, int b)
        {
            return a - b;
        }

        static int Mnozenje(int a, int b)
        {
            return a * b;
        }

        static int DeljenjeBezOstatka(int a, int b)
        {
            return a / b;
        }

        static float Deljenje(int a, int b)
        {
            return (float)a / (float)b;
        }

        static int OstatakPriDeljenju(int a, int b)
        {
            return a % b;
        }
    }
}
